var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/classes/route.js")
R.c("server/chunks/[root-of-the-server]__0kdxc9j._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0j.og_z._.js")
R.c("server/chunks/_next-internal_server_app_api_classes_route_actions_04gq42y.js")
R.m(76683)
module.exports=R.m(76683).exports
