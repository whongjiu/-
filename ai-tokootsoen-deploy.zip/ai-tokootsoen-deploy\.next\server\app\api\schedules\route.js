var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/schedules/route.js")
R.c("server/chunks/[root-of-the-server]__081mh.c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0j.og_z._.js")
R.c("server/chunks/_next-internal_server_app_api_schedules_route_actions_129kjsa.js")
R.m(29646)
module.exports=R.m(29646).exports
