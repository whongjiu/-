module.exports=[37779,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_leader_leave_page_actions_0o-klhr.js.map