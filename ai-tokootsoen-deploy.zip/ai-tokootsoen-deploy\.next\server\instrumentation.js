var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/[root-of-the-server]__10zfl39._.js")
R.m(23322)
module.exports=R.m(23322).exports
