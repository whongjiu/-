module.exports=[12290,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_parse-docx_route_actions_0-2fq2s.js.map