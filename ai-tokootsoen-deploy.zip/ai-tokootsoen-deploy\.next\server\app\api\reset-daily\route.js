var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/reset-daily/route.js")
R.c("server/chunks/[root-of-the-server]__0kn_zcg._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0j.og_z._.js")
R.c("server/chunks/_next-internal_server_app_api_reset-daily_route_actions_0ffv7k6.js")
R.m(52500)
module.exports=R.m(52500).exports
