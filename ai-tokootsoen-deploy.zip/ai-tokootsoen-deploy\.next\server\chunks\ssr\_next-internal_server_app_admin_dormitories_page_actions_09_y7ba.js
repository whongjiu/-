module.exports=[60078,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_dormitories_page_actions_09_y7ba.js.map