module.exports=[56907,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dormitories_route_actions_07mv9l1.js.map