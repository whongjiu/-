var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/invite-codes/route.js")
R.c("server/chunks/[root-of-the-server]__0yfv618._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0j.og_z._.js")
R.c("server/chunks/_next-internal_server_app_api_invite-codes_route_actions_09_vb83.js")
R.m(43058)
module.exports=R.m(43058).exports
