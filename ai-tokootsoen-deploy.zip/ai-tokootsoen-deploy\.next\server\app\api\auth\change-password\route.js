var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/change-password/route.js")
R.c("server/chunks/[root-of-the-server]__0-wyvk2._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0j.og_z._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_change-password_route_actions_07nd9z5.js")
R.m(56219)
module.exports=R.m(56219).exports
