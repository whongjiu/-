module.exports=[54681,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_change-password_route_actions_07nd9z5.js.map