module.exports=[66217,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_leader_page_actions_0xgh254.js.map