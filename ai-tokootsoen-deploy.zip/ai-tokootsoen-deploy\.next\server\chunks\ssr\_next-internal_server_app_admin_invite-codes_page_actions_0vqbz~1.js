module.exports=[79966,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_invite-codes_page_actions_0vqbz~1.js.map