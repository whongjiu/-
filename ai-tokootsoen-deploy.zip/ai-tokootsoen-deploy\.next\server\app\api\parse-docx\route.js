var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/parse-docx/route.js")
R.c("server/chunks/[externals]__0n~40jh._.js")
R.c("server/chunks/_0sz~0rx._.js")
R.c("server/chunks/[root-of-the-server]__13f3x8a._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_parse-docx_route_actions_0-2fq2s.js")
R.m(12970)
module.exports=R.m(12970).exports
