module.exports=[18371,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_reset-daily_route_actions_0ffv7k6.js.map