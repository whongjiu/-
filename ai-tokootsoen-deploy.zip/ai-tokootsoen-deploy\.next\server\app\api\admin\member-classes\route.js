var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/member-classes/route.js")
R.c("server/chunks/[root-of-the-server]__108.mxh._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0j.og_z._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_member-classes_route_actions_0h6xji2.js")
R.m(14536)
module.exports=R.m(14536).exports
