var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/rollcalls/attendance/route.js")
R.c("server/chunks/[root-of-the-server]__0tixw50._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0j.og_z._.js")
R.c("server/chunks/_next-internal_server_app_api_rollcalls_attendance_route_actions_0qhakha.js")
R.m(10943)
module.exports=R.m(10943).exports
