module.exports=[48798,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_report_page_actions_0jd8jnb.js.map