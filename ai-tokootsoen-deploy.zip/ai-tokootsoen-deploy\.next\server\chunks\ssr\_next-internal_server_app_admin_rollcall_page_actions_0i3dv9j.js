module.exports=[18218,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_rollcall_page_actions_0i3dv9j.js.map