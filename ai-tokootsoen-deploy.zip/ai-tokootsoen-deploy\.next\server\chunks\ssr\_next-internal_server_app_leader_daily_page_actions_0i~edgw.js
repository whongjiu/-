module.exports=[73803,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_leader_daily_page_actions_0i~edgw.js.map