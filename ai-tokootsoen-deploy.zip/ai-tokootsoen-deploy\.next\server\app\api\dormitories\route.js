var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/dormitories/route.js")
R.c("server/chunks/[root-of-the-server]__0op.u3o._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0j.og_z._.js")
R.c("server/chunks/_next-internal_server_app_api_dormitories_route_actions_07mv9l1.js")
R.m(15320)
module.exports=R.m(15320).exports
