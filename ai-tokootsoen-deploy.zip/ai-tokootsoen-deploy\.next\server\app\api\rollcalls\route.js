var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/rollcalls/route.js")
R.c("server/chunks/[root-of-the-server]__0.y.6uj._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0j.og_z._.js")
R.c("server/chunks/_next-internal_server_app_api_rollcalls_route_actions_0aavgwm.js")
R.m(21546)
module.exports=R.m(21546).exports
