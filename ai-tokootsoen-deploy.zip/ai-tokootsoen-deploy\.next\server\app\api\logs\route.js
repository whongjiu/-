var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/logs/route.js")
R.c("server/chunks/[root-of-the-server]__0br.f28._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0j.og_z._.js")
R.c("server/chunks/_next-internal_server_app_api_logs_route_actions_08ef2j7.js")
R.m(77917)
module.exports=R.m(77917).exports
