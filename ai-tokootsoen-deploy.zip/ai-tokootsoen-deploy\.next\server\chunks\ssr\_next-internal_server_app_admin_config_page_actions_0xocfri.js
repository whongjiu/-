module.exports=[12311,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_config_page_actions_0xocfri.js.map