var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/member-duties/route.js")
R.c("server/chunks/[root-of-the-server]__081rbad._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0j.og_z._.js")
R.c("server/chunks/_next-internal_server_app_api_member-duties_route_actions_0-abst_.js")
R.m(70791)
module.exports=R.m(70791).exports
