module.exports=[74756,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_duty-table_page_actions_0l2ji6a.js.map