module.exports=[34091,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admint_page_actions_02.~es~.js.map