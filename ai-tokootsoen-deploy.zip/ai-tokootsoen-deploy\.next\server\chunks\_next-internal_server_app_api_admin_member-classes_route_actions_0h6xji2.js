module.exports=[54264,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_member-classes_route_actions_0h6xji2.js.map