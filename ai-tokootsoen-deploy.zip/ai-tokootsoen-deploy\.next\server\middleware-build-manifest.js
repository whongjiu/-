globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/yTQ1yqtRTQRJGz1sLnd6T/_buildManifest.js",
    "static/yTQ1yqtRTQRJGz1sLnd6T/_ssgManifest.js",
    "static/yTQ1yqtRTQRJGz1sLnd6T/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0gscbv2oo_ix7.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/08h55_qyirajq.js",
    "static/chunks/turbopack-0v8vuh3gjso0w.js"
  ]
};
