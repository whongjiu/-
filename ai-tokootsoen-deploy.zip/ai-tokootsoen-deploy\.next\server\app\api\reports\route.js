var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/reports/route.js")
R.c("server/chunks/[root-of-the-server]__0q6fnoz._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0j.og_z._.js")
R.c("server/chunks/_next-internal_server_app_api_reports_route_actions_0~b0kjj.js")
R.m(28535)
module.exports=R.m(28535).exports
