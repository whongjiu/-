var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/config/route.js")
R.c("server/chunks/[root-of-the-server]__0dy7xk3._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0j.og_z._.js")
R.c("server/chunks/_next-internal_server_app_api_config_route_actions_08dm.dx.js")
R.m(37765)
module.exports=R.m(37765).exports
