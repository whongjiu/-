module.exports=[23998,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rollcalls_route_actions_0aavgwm.js.map