module.exports=[15825,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_member-classes_page_actions_0c9pzoq.js.map